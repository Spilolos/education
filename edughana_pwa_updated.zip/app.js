// Offline Lessons & Quizzes
const lessons = [
  { id: 1, title: "Mathematics Basics", content: "Numbers, addition, subtraction..." },
  { id: 2, title: "Science Basics", content: "Plants, animals, environment..." }
];

const quizzes = [
  { id: 1, question: "2 + 2 = ?", options: ["3", "4", "5"], answer: 1 },
  { id: 2, question: "What do plants need to grow?", options: ["Water", "Stone", "Plastic"], answer: 0 }
];

let progress = JSON.parse(localStorage.getItem("progress")) || { lessonsViewed: [], quizScores: {} };

document.getElementById("viewLessons").addEventListener("click", showLessons);
document.getElementById("viewQuizzes").addEventListener("click", showQuizzes);

function showLessons() {
  const container = document.getElementById("content");
  container.innerHTML = "<h2>Lessons</h2>";
  lessons.forEach(lesson => {
    const div = document.createElement("div");
    div.className = "lesson";
    div.innerHTML = `<h3>${lesson.title}</h3><p>${lesson.content}</p>`;
    container.appendChild(div);
    if (!progress.lessonsViewed.includes(lesson.id)) {
      progress.lessonsViewed.push(lesson.id);
      saveProgress();
    }
  });
}

function showQuizzes() {
  const container = document.getElementById("content");
  container.innerHTML = "<h2>Quizzes</h2>";
  quizzes.forEach(quiz => {
    const div = document.createElement("div");
    div.className = "quiz-question";
    div.innerHTML = `<p>${quiz.question}</p>`;
    quiz.options.forEach((opt, idx) => {
      const btn = document.createElement("button");
      btn.textContent = opt;
      btn.onclick = () => {
        const isCorrect = idx === quiz.answer;
        alert(isCorrect ? "Correct!" : "Wrong!");
        progress.quizScores[quiz.id] = isCorrect;
        saveProgress();
      };
      div.appendChild(btn);
    });
    container.appendChild(div);
  });
}

function saveProgress() {
  localStorage.setItem("progress", JSON.stringify(progress));
}

// Register Service Worker
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js");
}
